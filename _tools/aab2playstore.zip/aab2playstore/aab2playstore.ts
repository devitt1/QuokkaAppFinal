/*
  Script to help upload an .aab file to Google play store
  First convert the typescript file to pain js with:
  ./node_modules/.bin/tsc aab2playstore.ts

  Usage:
  node aab2playstore.js -t internal -p io.rokt.mobiletrainer -v 1.2.3 -k upload-key.json -a ../../build/app/outputs/bundle/release/app-release.aab

  source from here: https://studiolacosanostra.github.io/2020/01/06/How-to-publish-an-Android-App-Bundle-to-Google-Play-Console/
*/
import { ReadStream, createReadStream } from "fs";

import { google } from "googleapis";

const print = console.log;

type ThenArg<T> = T extends PromiseLike<infer U> ? U : T;

const getClient = (keyFile: string) =>
  google.auth.getClient({
    keyFile,
    scopes: "https://www.googleapis.com/auth/androidpublisher",
  });

const getAndroidPublisher = (
  client: ThenArg<ReturnType<typeof getClient>>,
  packageName: string
) =>
  google.androidpublisher({
    version: "v3",
    auth: client,
    params: {
      packageName,
    },
  });

const startEdit = (
  androidPublisher: ReturnType<typeof getAndroidPublisher>,
  id: string
) =>
  androidPublisher.edits.insert({
    requestBody: {
      id,
      expiryTimeSeconds: "600",
    },
  });

const upload = (
  androidPublisher: ReturnType<typeof getAndroidPublisher>,
  editId: string,
  packageName: string,
  aab: ReadStream
) =>
  androidPublisher.edits.bundles.upload({
    editId,
    packageName,
    media: {
      mimeType: "application/octet-stream",
      body: aab,
    },
  });

const setTrack = (
  androidPublisher: ReturnType<typeof getAndroidPublisher>,
  editId: string,
  releaseName: string,
  packageName: string,
  track: string,
  versionCode: string
) =>
  androidPublisher.edits.tracks.update({
    editId,
    track: track,
    packageName,
    requestBody: {
      track: track,
      releases: [
        {
          status: "completed",
          versionCodes: [versionCode],
          name: releaseName,
        },
      ],
    },
  });

const commit = (
  androidPublisher: ReturnType<typeof getAndroidPublisher>,
  editId: string,
  packageName: string
) =>
  androidPublisher.edits.commit({
    changesNotSentForReview: true,
    editId,
    packageName,
  });

const getAABStream = (filePath: string) => createReadStream(filePath);
const getId = () => String(new Date().getTime());

interface SchemaPublish {
  keyFile: string;
  versionName: string;
  packageName: string;
  aabFile: string;
  track: string;
}

export const publish = async ({
  keyFile,
  versionName,
  packageName,
  aabFile,
  track,
}: SchemaPublish) => {
  const client = await getClient(keyFile);
  const stream = getAABStream(aabFile);
  const androidPublisher = getAndroidPublisher(client, packageName);
  const id = getId();
  const edit = await startEdit(androidPublisher, id);
  const editId = String(edit.data.id);
  const bundle = await upload(androidPublisher, editId, packageName, stream);
  if (
    bundle.data.versionCode === undefined ||
    bundle.data.versionCode === null
  ) {
    throw new Error("Bundle versionCode cannot be undefined or null");
  }
  await setTrack(
    androidPublisher,
    editId,
    versionName,
    packageName,
    track,
    String(bundle.data.versionCode)
  );
  await commit(androidPublisher, editId, packageName);
};

const main = () => {
  if (process.argv.length !== 10 + 2) {
    print(
      "Usage: aab2playstore -t <track> -p <package_name> -v <version_name> -k <key_json> -a <aab_path>" +
        "where track can be: production, beta, alpha, internal" +
        `\n ${process.argv.length}`
    );
    process.exit(-1);
  }

  const parameters = {
    track: process.argv[2] == "-t" ? process.argv[3] : "",
    package: process.argv[4] == "-p" ? process.argv[5] : "",
    versionName: process.argv[6] == "-v" ? process.argv[7] : "",
    keyfile: process.argv[8] == "-k" ? process.argv[9] : "",
    aabfile: process.argv[10] == "-a" ? process.argv[11] : "",
  };

  print(parameters);

  publish({
    keyFile: parameters.keyfile,
    versionName: parameters.versionName,
    packageName: parameters.package,
    aabFile: parameters.aabfile,
    track: parameters.track,
  })
    .then(() => {
      print("Publish complete.");
    })
    .catch((error: Error) => {
      console.error(error.message);
    });
};

main();
