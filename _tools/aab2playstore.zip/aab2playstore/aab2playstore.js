"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
exports.publish = void 0;
/*
  Script to help upload an .aab file to Google play store
  First convert the typescript file to pain js with:
  ./node_modules/.bin/tsc aab2playstore.ts

  Usage:
  node aab2playstore.js -t internal -p io.rokt.mobiletrainer -v 1.2.3 -k upload-key.json -a ../../build/app/outputs/bundle/release/app-release.aab

  source from here: https://studiolacosanostra.github.io/2020/01/06/How-to-publish-an-Android-App-Bundle-to-Google-Play-Console/
*/
var fs_1 = require("fs");
var googleapis_1 = require("googleapis");
var print = console.log;
var getClient = function (keyFile) {
    return googleapis_1.google.auth.getClient({
        keyFile: keyFile,
        scopes: "https://www.googleapis.com/auth/androidpublisher"
    });
};
var getAndroidPublisher = function (client, packageName) {
    return googleapis_1.google.androidpublisher({
        version: "v3",
        auth: client,
        params: {
            packageName: packageName
        }
    });
};
var startEdit = function (androidPublisher, id) {
    return androidPublisher.edits.insert({
        requestBody: {
            id: id,
            expiryTimeSeconds: "600"
        }
    });
};
var upload = function (androidPublisher, editId, packageName, aab) {
    return androidPublisher.edits.bundles.upload({
        editId: editId,
        packageName: packageName,
        media: {
            mimeType: "application/octet-stream",
            body: aab
        }
    });
};
var setTrack = function (androidPublisher, editId, releaseName, packageName, track, versionCode) {
    return androidPublisher.edits.tracks.update({
        editId: editId,
        track: track,
        packageName: packageName,
        requestBody: {
            track: track,
            releases: [
                {
                    status: "completed",
                    versionCodes: [versionCode],
                    name: releaseName
                },
            ]
        }
    });
};
var commit = function (androidPublisher, editId, packageName) {
    return androidPublisher.edits.commit({
        changesNotSentForReview: true,
        editId: editId,
        packageName: packageName
    });
};
var getAABStream = function (filePath) { return (0, fs_1.createReadStream)(filePath); };
var getId = function () { return String(new Date().getTime()); };
var publish = function (_a) {
    var keyFile = _a.keyFile, versionName = _a.versionName, packageName = _a.packageName, aabFile = _a.aabFile, track = _a.track;
    return __awaiter(void 0, void 0, void 0, function () {
        var client, stream, androidPublisher, id, edit, editId, bundle;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, getClient(keyFile)];
                case 1:
                    client = _b.sent();
                    stream = getAABStream(aabFile);
                    androidPublisher = getAndroidPublisher(client, packageName);
                    id = getId();
                    return [4 /*yield*/, startEdit(androidPublisher, id)];
                case 2:
                    edit = _b.sent();
                    editId = String(edit.data.id);
                    return [4 /*yield*/, upload(androidPublisher, editId, packageName, stream)];
                case 3:
                    bundle = _b.sent();
                    if (bundle.data.versionCode === undefined ||
                        bundle.data.versionCode === null) {
                        throw new Error("Bundle versionCode cannot be undefined or null");
                    }
                    return [4 /*yield*/, setTrack(androidPublisher, editId, versionName, packageName, track, String(bundle.data.versionCode))];
                case 4:
                    _b.sent();
                    return [4 /*yield*/, commit(androidPublisher, editId, packageName)];
                case 5:
                    _b.sent();
                    return [2 /*return*/];
            }
        });
    });
};
exports.publish = publish;
var main = function () {
    if (process.argv.length !== 10 + 2) {
        print("Usage: aab2playstore -t <track> -p <package_name> -v <version_name> -k <key_json> -a <aab_path>" +
            "where track can be: production, beta, alpha, internal" +
            "\n ".concat(process.argv.length));
        process.exit(-1);
    }
    var parameters = {
        track: process.argv[2] == "-t" ? process.argv[3] : "",
        package: process.argv[4] == "-p" ? process.argv[5] : "",
        versionName: process.argv[6] == "-v" ? process.argv[7] : "",
        keyfile: process.argv[8] == "-k" ? process.argv[9] : "",
        aabfile: process.argv[10] == "-a" ? process.argv[11] : ""
    };
    print(parameters);
    (0, exports.publish)({
        keyFile: parameters.keyfile,
        versionName: parameters.versionName,
        packageName: parameters.package,
        aabFile: parameters.aabfile,
        track: parameters.track
    })
        .then(function () {
        print("Publish complete.");
    })["catch"](function (error) {
        console.error(error.message);
    });
};
main();
